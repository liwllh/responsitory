package com.empl.mgr.field;

public class TePositionField {

	//property constants
	public static final String PO_ID = "poId";
	public static final String PO_DEPARTMENT = "poDepartment";
	public static final String PO_NAME = "poName";
	public static final String PO_DESCRIPTION = "poDescription";
	public static final String PO_NUMBER = "poNumber";
	public static final String CREATOR = "creator";

}