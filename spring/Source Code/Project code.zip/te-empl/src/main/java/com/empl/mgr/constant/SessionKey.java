package com.empl.mgr.constant;

public class SessionKey {

	/*
	 * 账户登录session账户名称
	 * te5l.com [K]
	 */
	public static final String MODULEACCTNAME = "acctName";

	/*
	 * 验证码
	 * te5l.com [K]
	 */
	public static final String VALIDATE_CODE = "VALIDATECODE";

}
