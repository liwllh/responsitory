package com.empl.mgr.field;

public class TeProvinceField {

	public static final String PROVINCE_NAME = "provinceName";
	public static final String PROVINCE_CODE = "provinceCode";
	public static final String LANGUAGE = "language";

}