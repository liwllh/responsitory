package com.empl.mgr.field;

public class TeChoosePoliticsField {

	//property constants
	public static final String POL_NAME = "polName";

}