package com.empl.mgr.service;

public interface RoleModuleService {
	
}
