package com.empl.mgr.field;

public class TeCountyField {

	public static final String COUNTY_NAME = "countyName";
	public static final String COUNTY_CODE = "countyCode";
	public static final String CITY_ID = "cityId";

}