package com.empl.mgr.constant;

public class AccountDeleteState {

	/*
	 * 删除
	 * te5l.com [K]
	 */
	public static final boolean IS_DELETE = true;

	/*
	 * 未删除
	 * te5l.com [K]
	 */
	public static final boolean NO_DELETE = false;

}
