package com.empl.mgr.constant;

public class AccountInitPassword {

	/*
	 * 初始化密码
	 * te5l.com [K]
	 */
	public static final String ACCOUNT_INIT_PASSWORD = "www.te5l.com";

}
