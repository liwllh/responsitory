package com.empl.mgr.constant;

public class AccountState {

	/*
	 * 普通会员
	 * te5l.com [K]
	 */
	public static final int ACCOUNT_GENERAL = 0;

}
