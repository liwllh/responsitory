package com.empl.mgr.field;

public class TeModuleField {

	public static final String MODULE_NAME = "moduleName";
	public static final String MODULE_CODE = "moduleCode";
	public static final String MODULE_SUPER_CODE = "moduleSuperCode";
	public static final String MODULE_PAGE = "modulePage";
	public static final String MODULE_LEVEL = "moduleLevel";

}