package com.empl.mgr.field;

public class TeEmployeesCompanyField {

	//property constants
	public static final String EMPL_NO = "emplNo";
	public static final String COM_NAME = "comName";
	public static final String COM_PARTICIPATE_TIME = "comParticipateTime";
	public static final String COM_LEAVE_TIME = "comLeaveTime";
	public static final String COM_POSITION = "comPosition";
	public static final String COM_REASON = "comReason";

}