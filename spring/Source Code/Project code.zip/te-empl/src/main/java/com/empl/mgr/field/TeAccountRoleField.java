package com.empl.mgr.field;

public class TeAccountRoleField {

	//property constants
	public static final String ACCT_NAME = "acctName";
	public static final String ROLE_LABEL = "roleLabel";

}