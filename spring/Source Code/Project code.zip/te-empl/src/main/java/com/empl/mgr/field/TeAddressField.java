package com.empl.mgr.field;

public class TeAddressField {

	public static final String ADS_ID = "adsId";
	public static final String ADS_TYPE = "adsType";
	public static final String ADS_PROVINCE = "adsProvince";
	public static final String ADS_CITY = "adsCity";
	public static final String ADS_COUNTY = "adsCounty";
	public static final String ADS_TOWNSHIP = "adsTownship";
	public static final String ADS_VILLAGE = "adsVillage";
	public static final String ADS_DETAILED = "adsDetailed";

}