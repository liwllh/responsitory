package com.empl.mgr.field;

public class TeTrainingField {

	//property constants
	public static final String ID = "id";
	public static final String NAME = "name";
	public static final String DESCRIPTION = "description";
	public static final String NUMBER = "number";
	public static final String START_TIME = "startTime";
	public static final String END_TIME = "endTime";
	public static final String IS_INSERT_ATTEND = "isInsertAttend";
	public static final String STATE = "state";
	public static final String CREATOR = "creator";

}