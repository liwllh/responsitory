package com.empl.mgr.field;

public class TeChooseMarriageField {
	
	public static final String MAR_NAME = "marName";
	
}