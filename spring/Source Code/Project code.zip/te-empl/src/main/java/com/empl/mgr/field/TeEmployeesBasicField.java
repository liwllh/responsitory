package com.empl.mgr.field;

public class TeEmployeesBasicField {

	//property constants
	public static final String EM_ID = "emId";
	public static final String EM_STATE = "emState";
	public static final String EM_PHOTO = "emPhoto";
	public static final String EM_FULL_NAME = "emFullName";
	public static final String EM_SEX = "emSex";
	public static final String EM_IDENTITY = "emIdentity";
	public static final String EM_BIRTHDAY = "emBirthday";
	public static final String EM_PARTICIPATE_TIME = "emParticipateTime";
	public static final String EM_PHONE = "emPhone";
	public static final String EM_SOCIAL_SECURITY = "emSocialSecurity";
	public static final String EM_DEPAREMTN = "emDeparemtn";
	public static final String EM_POSITION = "emPosition";
	public static final String EM_EDUCATION = "emEducation";
	public static final String EM_MARRIAGE = "emMarriage";
	public static final String EM_POLITICS = "emPolitics";
	public static final String EM_NATIONAL = "emNational";
	public static final String EM_CURRENT_ADDRESS = "emCurrentAddress";
	public static final String EM_CENSUS_REGISTER = "emCensusRegister";
	public static final String CREATOR = "creator";

}