package com.empl.mgr.constant;

public class PhoneImageSize {

	/*
	 * 头像上传最大不操作1MB
	 */
	public static final int PHONE_IMAGE_SIZE = 1024 * 1000;

}
