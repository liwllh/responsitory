package com.empl.mgr.field;

public class TeTrainingNoteField {

	//property constants
	public static final String TRAINING_ID = "trainingId";
	public static final String STATE = "state";
	public static final String NOTE = "note";
	public static final String CREATOR = "creator";

}