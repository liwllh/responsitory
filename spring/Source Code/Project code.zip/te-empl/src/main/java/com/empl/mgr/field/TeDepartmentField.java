package com.empl.mgr.field;

public class TeDepartmentField {

	public static final String DEPT_ID = "deptId";
	public static final String DEPT_NAME = "deptName";
	public static final String CREATOR = "creator";
	public static final String DEPT_DESCRIPTION = "deptDescription";
	public static final String DEPT_PRINCIPAL = "deptPrincipal";

}