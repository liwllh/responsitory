package com.empl.mgr.field;

public class TeAccountField {

	public static final String ACCT_ID = "acctId";
	public static final String ACCT_NAME = "acctName";
	public static final String ACCT_NICKNAME = "acctNickname";
	public static final String ACCT_PASSWORD = "acctPassword";
	public static final String ACCT_STATE = "acctState";
	public static final String ACCT_SUPER = "acctSuper";
	public static final String ACCT_DELETE_STATE = "acctDeleteState";
	public static final String CREATOR = "creator";

}