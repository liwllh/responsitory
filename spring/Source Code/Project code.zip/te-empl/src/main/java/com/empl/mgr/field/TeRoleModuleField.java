package com.empl.mgr.field;

public class TeRoleModuleField {

	//property constants
	public static final String ROLE_LABEL = "roleLabel";
	public static final String MODULE_CODE = "moduleCode";
	public static final String FINDS = "finds";
	public static final String ADDS = "adds";
	public static final String DELETES = "deletes";
	public static final String MODIFYS = "modifys";

}