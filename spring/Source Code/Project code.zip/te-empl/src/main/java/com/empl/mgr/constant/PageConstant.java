package com.empl.mgr.constant;

public class PageConstant {

	/*
	 * 普通数据列表
	 * te5l.com [K]
	 */
	public static final int PAGE_LIST = 15;

}
