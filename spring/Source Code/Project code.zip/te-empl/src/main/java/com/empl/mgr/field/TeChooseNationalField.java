package com.empl.mgr.field;

public class TeChooseNationalField {
	
	//property constants
	public static final String NAT_NAME = "natName";
	
}