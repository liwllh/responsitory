var moduleCode = '0';
function initFun(){}